package com.capg.film.repo;

import java.util.List;

import com.capg.film.bean.Actor;
import com.capg.film.bean.Film;

public interface ActorRepo {
	public Actor save(Actor actor);

	public List<Actor> searchByName(String firstName, String lastName);

	public List<Actor> searchByAge(byte age);

	public Actor modifyActor(int id, Actor actor);

	public Boolean deleteActor(String name);
}
