package com.capg.film.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capg.film.service.ActorServiceImpl;
import com.capg.film.service.FilmServiceImpl;

public class UserInterface {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		FilmServiceImpl filmService = new FilmServiceImpl(em);
		ActorServiceImpl actorService = new ActorServiceImpl(em);

		em.getTransaction().begin();

		
		// 1st film Details---------------------------------------------------//

		/*List<String> filmImg = new ArrayList<String>();
		filmImg.add("url1");
		filmImg.add("url2");
		filmImg.add("url3");

		HashMap imgMap = new HashMap();
		imgMap.put("album", filmImg);

		HashMap actor1 = new HashMap();
		actor1.put("firstName", "Hrutik");
		actor1.put("lastName", "Roshan");
		actor1.put("gender", "male");

		HashMap actor2 = new HashMap();
		actor2.put("firstName", "Anushka");
		actor2.put("lastName", "Sharma");
		actor2.put("gender", "female");
		
		HashMap actor3 = new HashMap();
		actor3.put("firstName", "Rani");
		actor3.put("lastName", "Mukharji");
		actor3.put("gender", "female");

		HashMap actor4 = new HashMap();
		actor4.put("firstName", "Diya");
		actor4.put("lastName", "Mirza");
		actor4.put("gender", "female");

		List<HashMap> actorList = new ArrayList<HashMap>();
		actorList.add(actor1);
		actorList.add(actor3);
		actorList.add(actor4);
		
		HashMap category1 = new HashMap();
		category1.put("name", "Biopic");
		

		List<HashMap> categoryList = new ArrayList<HashMap>();
		categoryList.add(category1);

		HashMap film = new HashMap();
		film.put("title", "sole");
		film.put("releaseYear", 2000);
		film.put("rating", 4);
		film.put("length", 120);
		film.put("language", "hindi");
		film.put("imgMap", imgMap);
		film.put("albumName", "Khabhi khushi Kabhi gum");
		film.put("actors", actorList);
		film.put("categorys", categoryList);
		film.put("description", "Family Movie show the love of two brother");
		film.put("createDate", new Date());

		filmService.addFilm(film);*/

		
		/*System.out.println("- --------------2 Film Details --------------- ");
		List<String> filmImg1 = new ArrayList<String>();
		filmImg1.add("urldf");
		filmImg1.add("urlgsdhgh");
		filmImg1.add("url33eqow");

		HashMap imgMap1 = new HashMap();
		imgMap1.put("album", filmImg1);

		HashMap actor11 = new HashMap();
		actor11.put("firstName", "Poppy");
		actor11.put("lastName", "Montgomery");
		actor11.put("gender", "female");

		HashMap actor22 = new HashMap();
		actor22.put("firstName", "Adam ");
		actor22.put("lastName", "Kaufman");
		actor22.put("gender", "male");

		List<HashMap> actorList1 = new ArrayList<HashMap>();
		actorList1.add(actor11);
		actorList1.add(actor22);

		HashMap category11 = new HashMap();
		category11.put("name", "Comedy");

		HashMap category22 = new HashMap();
		category22.put("name", "Romentic");

		List<HashMap> categoryList1 = new ArrayList<HashMap>();
		categoryList1.add(category11);
		categoryList1.add(category22);

		HashMap film1 = new HashMap();
		film1.put("title", "Lying to Be Perfect");
		film1.put("releaseYear", 2010);
		film1.put("rating", 5);
		film1.put("length", 120);
		film1.put("language", "English");

		film1.put("albumName", "Hollywood");
		film1.put("actors", actorList1);
		film1.put("categorys", categoryList1);
		film1.put("imgMap", imgMap1);
		film1.put("description",
				"An overweight magazine editor (Poppy Montgomery) leads a double life as a sassy advice columnist at night. To keep her alter ego a secret, she agrees to lose weight with two of her friends and embarks on a life-changing journey.");
		film1.put("createDate", new Date());

		filmService.addFilm(film1);*/

		
		//3 rd Film details------------------------------------------------------------//
	List<String> filmImg2 = new ArrayList<String>();
		filmImg2.add("urwl");
		filmImg2.add("urlll");
		filmImg2.add("urrt");

		HashMap imgMap2 = new HashMap();
		imgMap2.put("album", filmImg2);

		HashMap actor111 = new HashMap();
		actor111.put("firstName", "Salman");
		actor111.put("lastName", "Khan");
		actor111.put("gender", "male");

		HashMap actor222 = new HashMap();
		actor222.put("firstName", "Saif Ali");
		actor222.put("lastName", "Khan");
		actor222.put("gender", "male");

		HashMap actor333 = new HashMap();
		actor333.put("firstName", "Karishma");
		actor333.put("lastName", "Kapoor");
		actor333.put("gender", "female");

		HashMap actor444 = new HashMap();
		actor444.put("firstName", "Sonali");
		actor444.put("lastName", "Bendre");
		actor444.put("gender", "female");

		HashMap actor555 = new HashMap();
		actor444.put("firstName", "Tabu");
		actor444.put("lastName", "Fatima");
		actor444.put("gender", "female");

		List<HashMap> actorList2 = new ArrayList<HashMap>();
		actorList2.add(actor111);
		actorList2.add(actor222);
		actorList2.add(actor333);
		actorList2.add(actor444);
		actorList2.add(actor555);

		HashMap category111 = new HashMap();
		category111.put("name", "Action");

		List<HashMap> categoryList11 = new ArrayList<HashMap>();
		categoryList11.add(category111);

		HashMap film2 = new HashMap();
		film2.put("title", "Hum Sath Sath Hai");
		film2.put("releaseYear", 1999);
		film2.put("rating", 5);
		film2.put("length", 120);
		film2.put("language", "Hindi");
		film2.put("imgMap", imgMap2);
		film2.put("albumName", "pqw");
		film2.put("actors", actorList2);
		film2.put("categorys", categoryList11);
		film2.put("description",
				"Ramkishen and Mamta have three sons, Vivek, Prem and Vinod. As Vivek is Mamta's stepson, she embitters her heart towards him for the sake of her own sons. Vivek dutifully accepts her decision.");
		film2.put("createDate", new Date());

		System.out.println(filmService.addFilm(film2));

		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
