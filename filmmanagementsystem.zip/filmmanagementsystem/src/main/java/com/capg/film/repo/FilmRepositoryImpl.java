package com.capg.film.repo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capg.film.bean.Actor;
import com.capg.film.bean.Album;
import com.capg.film.bean.Category;
import com.capg.film.bean.Film;
import com.capg.film.bean.Image;

public class FilmRepositoryImpl implements FilmRepo{
	private EntityManager em;

	public FilmRepositoryImpl(EntityManager em) {
		this.em = em;
	}

	public Film save(Film film) {
		try {
			em.persist(film);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return film;
	}

	public List<Film> searchByCategory(String name) {
	
		return null;

	}

	public List<Film> searchByActor(String actor) {

		return null;

	}

	public List<Film> searchByRating(byte rating) {

		return null;

	}

	public Boolean modifyFilm(int id,Film film) {

		
		return false;
	}

	public Boolean deleteFilm(String title) {
	
		return false;
	}

	public List<Film> searchByTitle(String title) {
	
		return null;

	}

	public List<Film> searchByLanguage(String language) {

		return null;
	}

	public List<Film> searchByReleaseYear(int year) {
	
		return null;
	}

	public Album findAlbum(String string) {
		try {

			System.out.println("in find album");
			TypedQuery<Album> query = em.createQuery("SELECT a FROM Album a WHERE a.Name LIKE :nam", Album.class);
			Album album = (Album) query.setParameter("nam", string).getSingleResult();

			return album;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Category findCategory(String string) {
		try {

			TypedQuery<Category> query = em.createQuery("Select a from Category a where a.name like :nam",
					Category.class);
			Category c = query.setParameter("nam", string).getSingleResult();
			System.out.println(c);
			return c;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Album addAlbum(Album album) {

		em.persist(album);
		System.out.println("album save");
		return album;
	}

	public Image addImage(Image img) {

		try {

			em.persist(img);
			return img;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public Category addCategory(Category c) {
		
			em.persist(c);
			return c;
		
	}

	public Album setImageOnAlbum(String name, List<Image> images) {
	
		System.out.println("in set img" + name);
		Album album = findAlbum(name);
		album.setImage(images);
		em.persist(album);
		System.out.println("end set img");
		return album;
	}

	public Category setFilmOnCategory(String name, List<Film> film) {

		Category c = findCategory(name);
		c.setFilm(film);
		em.persist(c);
		return c;

	}

	public Actor setFilmsOnActor(String name, List<Film> film) {
		Actor a = findActor(name);
		a.setFilm(film);
		em.persist(a);
		return a;
	}

	public Actor findActor(String string) {
		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor a = query.setParameter("nam", string).getSingleResult();
			System.out.println(a);
			return a;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public Album modifyAlbum(int j, Album album) {
	
		return null;
	}

}
