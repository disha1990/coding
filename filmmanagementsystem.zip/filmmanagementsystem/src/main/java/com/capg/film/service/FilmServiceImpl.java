package com.capg.film.service;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.engine.transaction.jta.platform.internal.SynchronizationRegistryBasedSynchronizationStrategy;

import com.capg.film.bean.Actor;
import com.capg.film.bean.Album;
import com.capg.film.bean.Category;
import com.capg.film.bean.Film;
import com.capg.film.bean.Image;
import com.capg.film.repo.ActorRepo;
import com.capg.film.repo.ActorRepositoryImpl;
import com.capg.film.repo.FilmRepositoryImpl;


public class FilmServiceImpl implements FilmService {

	private FilmRepositoryImpl filmRepo;
	private ActorRepo actorRepo;
	private Category category;
	private Actor actor;

	public FilmServiceImpl(FilmRepositoryImpl filmRepo) {
		this.filmRepo = filmRepo;
	}

	public FilmServiceImpl(EntityManager em) {
		filmRepo = new FilmRepositoryImpl(em);
		actorRepo = new ActorRepositoryImpl(em);
	}

	public FilmServiceImpl() {
	}

	public String addFilm(HashMap map) {
		if (map == null) {
			throw new NullPointerException();

		} else {

			try {
				String title = (String) map.get("title");

				List<HashMap> categoryMap = (List<HashMap>) map.get("categorys");
				System.out.println("size cat : " + categoryMap.size());
				List<Category> categoryList = new ArrayList<Category>();
				for (HashMap m : categoryMap) {
					Category c = new Category();
					c.setName((String) m.get("name"));
					c.setCreateDate((Date) map.get("createDate"));
					categoryList.add(c);
					category = filmRepo.addCategory(c);

				}
				Album album = new Album();
				album.setName((String) map.get("albumName"));
				album.setCreateDate((Date) map.get("createDate"));
				album = filmRepo.addAlbum(album);

				System.out.println("end album");
				HashMap imgMap = (HashMap) map.get("imgMap");
				List<String> urlList = (List<String>) imgMap.get("album");
				List<Image> iList = new ArrayList<Image>();
				for (String url : urlList) {

					Image i = new Image();
					i.setUrl(url);
					i.setAlbum(album);
					i.setCreatedate((Date) map.get("createDate"));
					iList.add(i);
					filmRepo.addImage(i);

				}
				System.out.println("image end");
				album = filmRepo.setImageOnAlbum(album.getName(), iList);
				System.out.println("after image album mapping");

				List<HashMap> actorMap = (List<HashMap>) map.get("actors");
				List<Actor> actorsList = new ArrayList<Actor>();
				for (HashMap a : actorMap) {

					Actor ac = new Actor();
					ac.setFirstName((String) a.get("firstName"));
					ac.setLastName((String) a.get("lastName"));
					ac.setGender((String) a.get("gender"));
					ac.setAlbum(album);
					ac.setCreateDate((Date) map.get("createDate"));
					actorsList.add(ac);

					actor = actorRepo.save(ac);

				}
				Film film = new Film();
				film.setTitle(title);
				film.setLanguage((String) map.get("language"));

				film.setDescription((String) map.get("description"));
				byte b = ((Integer) map.get("rating")).byteValue();
				film.setRating(b);
				film.setReleaseYear(((Integer) map.get("releaseYear")).intValue());
				film.setLength(((Integer) map.get("length")).shortValue());
				film.setCreateDate((Date) map.get("createDate"));
				film.setActor(actorsList);
				film.setCategory(categoryList);
				film.setAlbum(album);

				film = filmRepo.save(film);

				List<Film> list = new ArrayList<Film>();
				list.add(film);

				filmRepo.setFilmOnCategory(category.getName(), list);
				filmRepo.setFilmsOnActor(actor.getFirstName(), list);
				return "success";

			} catch (Exception e) {
				e.printStackTrace();
				return "error";
			}
		}

	}

	public List searchByCategory(String name) {

		return null;

	}

	public List<Film> searchByActor(String first) {

		return null;
	}

	public List<Film> searchByRating(byte rating) {
	
		return null;
	}

	public String modifyFilm(HashMap map) {
	
		return null;

	}

	public String deleteFilm(String title) {

		return null;

	}

	public List<Film> searchByTitle(String title) {
		
		return null;

	}

	public List<Film> searchByLanguage(String language) {
	
		return null;
	}

	public List<Film> searchByReleaseYear(int year) {
	
		return null;
	}

	public Category setCategoryOnFilm(int id, List<Film> film) {
		Category c = new Category();
		c.setFilm(film);
		// em.persist(c);
		return c;

	}

	public Album setImageOnAlbum(String string, List<Image> images) {

		
		Album album = filmRepo.findAlbum(string);
		album.setImage(images);
		album = filmRepo.addAlbum(album);
		return album;
	}

	public Album createAlbum(String s) {
		Album album = new Album();
		album.setName(s);
		Album a = filmRepo.addAlbum(album);
		return a;
	
	}

	public Image createImage(String string, Album album1) {
		Image img = new Image();
		img.setUrl(string);
		img.setAlbum(album1);
		Image i = filmRepo.addImage(img);
		return i;
	
	}

}



